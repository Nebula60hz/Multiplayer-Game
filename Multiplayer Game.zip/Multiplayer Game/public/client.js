var socket = io();

socket.on('connect', () => {
  console.log("connected to 3000");
});

var pressed = false;

var chats = [];

var players = [];
var gameObjects = [];
var thisPlayer = {
  x:0,
  y:0,
  targetX:0,
  targetY:0,
  id:0,
  rgb:{},
  username:"",
  angle:0,
  speed:5,
  health:0,
};
var xspeed = 0;
var yspeed = 0;

var ping = 0;

var tickRate = 32;
var movementMultiplier = 0;

setInterval(() => {
  const start = Date.now();

  socket.emit("ping", () => {
    const duration = Date.now() - start;
    ping = duration;
    console.log("Current Server ms:" + duration);
  });
}, 1000);

socket.on('tick-rate', (rate) => {
  movementMultiplier = (rate/tickRate);
  console.log("Received server tick rate: " + rate);
  console.log("Our tick rate: " + tickRate + "\nClient predicted movement multiplier: " + movementMultiplier);
});

socket.on('disconnect', (reason) => {
  console.log("Dissconnected, reason: "+reason);
  alert("You've been disconnected, reason: "+reason + "\nPlease reload your tab");
});

setInterval(() => {
  try {
    updateServer();
  } catch(e) {
    console.log(e);
  }
}, 1000/tickRate);

const usernameInput = document.getElementById('username');
if (usernameInput) {
  socket.emit('username', usernameInput.value);
}

class Player {
  constructor(player) {
    this.x = player.x;
    this.y = player.y;
    this.id = player.id;
    this.rgb = player.rgb;
    this.username = player.username;
    this.angle = player.angle;
    this.speed = player.speed;
    this.targetX = player.targetX;
    this.targetY = player.targetY;
    this.health = player.health;
  }

  interpolate() {
    // Client-side interpolation for player position
    this.x += (this.targetX - this.x) * 0.1;
    this.y += (this.targetY - this.y) * 0.1;
  }

  update() {
    if (this.id!==socket.id) {
      this.interpolate();
    }
    this.draw();
  }

  draw() {
    push();
    stroke(51);
    if (this.id===socket.id) {
      strokeWeight(4);
      translate(400, 300);
    } else {
      strokeWeight(1);
      translate(this.x, this.y);
    }

    fill(0);
    textSize(20);
    textAlign(CENTER, CORNER);
    text(this.username, 0, -30);
    fill(this.rgb.r, this.rgb.g, this.rgb.b);
    circle(0, 0, 40);

    line(0, 0, cos(this.angle)*-40, sin(this.angle)*-40);

    pop();
  }
}

class GameObject {
  constructor(object) {
    this.x = object.x;
    this.y = object.y;
    this.targetX = object.targetX;
    this.targetY = object.targetY;
    this.xspeed = object.xspeed * movementMultiplier;
    this.yspeed = object.yspeed * movementMultiplier;
  }

  interpolate() {
    // Client-side interpolation for bullet position
    this.x += (this.targetX - this.x) * 0.1;
    this.y += (this.targetY - this.y) * 0.1;
  }

  update() {
    this.interpolate();
    this.draw();
  }

  draw() {
    push();
    stroke(51);
    if (this.id===socket.id) {
      strokeWeight(4);
    } else {
      strokeWeight(1);
    }

    translate(this.x, this.y);

    fill(0);
    textSize(20);
    circle(0, 0, 10);

    pop();
  }
}

socket.on('heartbeat', (playersFromServer, gameObjectsFromServer) => {
  updatePlayers(playersFromServer);
  updateGameObjects(gameObjectsFromServer);
});

socket.on('died', (id) => {
  if (id===socket.id) {
    chats.push("You died, reload you page to restart");
  }
});

socket.on('log', (msg) => {
  console.log(msg);
  chats.push(msg);
});

function setup() {
  createCanvas(800, 600);
}

function draw() {
  try {
    background(220);

  if(chats.length>20) {
    chats = [];
  }
  for (var i = 0; i<chats.length; i++) {
    text(chats[i], 10, 10+i*20)
  }

  text("x:"+round(thisPlayer.x), 10, 590);
  text("y:"+round(thisPlayer.y), 50, 590);
  text("ms:"+round(ping), 760, 10);

  if (thisPlayer) {
    if (xspeed !== 0 || yspeed !== 0) {
      thisPlayer.targetX += xspeed * movementMultiplier;
      thisPlayer.targetY += yspeed * movementMultiplier;
    }

    thisPlayer.angle = atan2(300 - mouseY, 400 - mouseX);
  }
  push();

  translate(-thisPlayer.x+400, -thisPlayer.y+300);

  players.forEach((player) => {
    if (player.id!==thisPlayer.id) {
      player.update();
    }
});
  gameObjects.forEach((object) => object.update());

  pop();

  if (thisPlayer.id===socket.id) {
    thisPlayer.update();
  }
  } catch (e) {
    console.log(e);
  }
}

function updateServer() {
  socket.emit('update', {
    id: socket.id,
    type: 'position',
    targetX: thisPlayer.targetX,
    targetY: thisPlayer.targetY,
  });

  socket.emit('update', {
    id:socket.id,
    type:'rotation',
    angle: atan2(300 - mouseY, 400 - mouseX),
  });

  const usernameInput = document.getElementById('username');
  if (usernameInput) {
    socket.emit('username', usernameInput.value);
  }
}

function updatePlayers(serverPlayers) {
  if (serverPlayers) {
    players = serverPlayers.map(
    (playerFromServer) => playerFromServer && new Player(playerFromServer)
  );
    thisPlayer = getPlayer(socket.id);
  }
}

function updateGameObjects(serverObjects) {
  if (serverObjects) {
    gameObjects = serverObjects.map(
      (objectFromServer) => objectFromServer && new GameObject(objectFromServer)
    );
  }
}

function getPlayer(id) {
  return players.find((player) => player.id === id);
}

function keyPressed() {
  switch (keyCode) {
    case LEFT_ARROW:
    case 65:
      xspeed = -thisPlayer.speed;
        break;
    case RIGHT_ARROW:
    case 68:
      xspeed = thisPlayer.speed;
      break;
    case UP_ARROW:
    case 87:
      yspeed = -thisPlayer.speed;
      break;
    case DOWN_ARROW:
    case 83:
      yspeed = thisPlayer.speed;
    break;
  }
}

function keyReleased() {
  switch (keyCode) {
    case LEFT_ARROW:
    case 65:
      xspeed = 0;
      break;
    case RIGHT_ARROW:
    case 68:
      xspeed = 0;
      break;
    case UP_ARROW:
    case 87:
      yspeed = 0;
      break;
    case DOWN_ARROW:
    case 83:
      yspeed = 0;
      break;
  }
}

function mousePressed() {
  socket.emit('update', {
      id:socket.id,
      type:"attack-start",
    });
  console.log('attack-start');
}

function mouseReleased() {
  socket.emit('update', {
      id:socket.id,
      type:"attack-end",
    });
  console.log('attack-end');
}
