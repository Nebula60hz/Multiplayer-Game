var socket = io("/");

socket.on('connect', () => {
  console.log("connected to 3000");
});

angleMode = "degrees";

var pressed = false;

var chats = [];

var players = [];
var thisPlayer = {};

var xspeed = 0;
var yspeed = 0;

var ping = 0;

var tickRate = 1;

setInterval(() => {
  const start = Date.now();

  socket.emit("ping", () => {
    const duration = Date.now() - start;
    console.log("Current Server ms:" + duration);
  });
}, 1000);

socket.on('tick-rate', (rate) => {
  tickRate = rate;
  const baseRate = 64;
  console.log("Received server tick rate: " + rate);
  console.log("Base rate:"+baseRate+"\nOur tick rate:"+tickRate);
});
setInterval(updateServer, 1000/50);

const usernameInput = document.getElementById('username');
if (usernameInput) {
  socket.emit('username', usernameInput.value);
}

class Player {
  constructor(player) {
    this.x = player.x;
    this.y = player.y;
    this.id = player.id;
    this.rgb = player.rgb;
    this.username = player.username;
    this.angle = player.angle;
    this.speed = player.speed;
    this.targetX = player.targetX;
    this.targetY = player.targetY;
  }

  check() {
    if (this.id===socket.id) {
      thisPlayer = this;
    }
  }

  interpolate() {
    // Client-side interpolation for player position
    this.x += (this.targetX - this.x) * 0.1;
    this.y += (this.targetY - this.y) * 0.1;
  }

  update() {
    this.interpolate();
  }

  draw() {
    push();
    stroke(51);
    if (this.id===socket.id) {
      strokeWeight(4);
    } else {
      strokeWeight(1);
    }

    translate(this.x, this.y);

    fill(0);
    textSize(20);
    textAlign(CENTER, CORNER);
    text(this.username, 0, -30);
    fill(this.rgb.r, this.rgb.g, this.rgb.b);
    circle(0, 0, 40);

    line(0, 0, cos(this.angle)*-40, sin(this.angle)*-40);

    pop();
  }
}

socket.on('heartbeat', (data) => {
  updatePlayers(data);
});

socket.on('log', (msg) => {
  console.log(msg);
  chats.push(msg);
});

function setup() {
  createCanvas(800, 600);
  setPlayer();
}

function draw() {
  background(220);

  if(chats.length>20) {
    chats = [];
  }
  for (var i = 0; i<chats.length; i++) {
    text(chats[i], 10, 10+i*20)
  }

  setPlayer();

  if (thisPlayer) {
    if (xspeed !== 0 || yspeed !== 0) {
      thisPlayer.targetX += xspeed;
      thisPlayer.targetY += yspeed;
    }

    thisPlayer.angle = atan2(thisPlayer.y - mouseY, thisPlayer.x - mouseX);
  } else {
    socket.emit('player-error');
  }

  players.forEach((player) => player.update());
  players.forEach((player) => player.draw());
}

function updateServer() {
  socket.emit('update', {
    id: socket.id,
    type: 'position',
    targetX: thisPlayer.targetX,
    targetY: thisPlayer.targetY,
  });

  socket.emit('update', {
    id:socket.id,
    type:'rotation',
    angle: atan2(thisPlayer.y - mouseY, thisPlayer.x - mouseX),
  });

  if (pressed) {
    socket.emit('update', {
      id:socket.id,
      type:"attack",
    });
  }
}

function updatePlayers(serverPlayers) {
  players = serverPlayers.map(
    (playerFromServer) => playerFromServer && new Player(playerFromServer)
  );
}

function setPlayer() {
  players.forEach((player) => player.check());
}

function keyPressed() {
  switch (keyCode) {
    case LEFT_ARROW:
    case 65:
      xspeed = -thisPlayer.speed;
        break;
    case RIGHT_ARROW:
    case 68:
      xspeed = thisPlayer.speed;
      break;
    case UP_ARROW:
    case 87:
      yspeed = -thisPlayer.speed;
      break;
    case DOWN_ARROW:
    case 83:
      yspeed = thisPlayer.speed;
    break;
  }
}

function keyReleased() {
  switch (keyCode) {
    case LEFT_ARROW:
    case 65:
      xspeed = 0;
      break;
    case RIGHT_ARROW:
    case 68:
      xspeed = 0;
      break;
    case UP_ARROW:
    case 87:
      yspeed = 0;
      break;
    case DOWN_ARROW:
    case 83:
      yspeed = 0;
      break;
  }
}

function mousePressed() {
  pressed = true;
}

function mouseReleased() {
  pressed = false;
}
