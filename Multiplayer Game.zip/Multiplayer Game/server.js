const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);

const PORT = process.argv.includes('--port') ? process.argv[process.argv.indexOf('--port') + 1] || 3000 : 3000;

const tickValue = process.argv.includes('--tick-rate') ? process.argv[process.argv.indexOf('--tick-rate') + 1] || 64 : 64;
const tickRate = parseInt(tickValue, 10);
let ticksPassed = 0;

const serverHealth = 100;
const serverAttackTimer = tickRate; // one-second attack cooldown
const serverDamage = 25;

app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/client.html');
});

class Player {
  constructor(id) {
    this.id = id;
    this.username = "";
    this.roomId = 0;
    this.angle = 0;
    this.health = serverHealth;
    this.attackTimer = serverAttackTimer;
    this.canAttack = true;
    this.speed = 10;

    this.rgb = {
      r: Math.random() * 255,
      g: Math.random() * 255,
      b: Math.random() * 255,
    };

    // Server-side target coordinates
    this.targetX = Math.random() * 800;
    this.targetY = Math.random() * 600;

    this.x = this.targetX;
    this.y = this.targetY;
  }

  update() {
    this.x += (this.targetX - this.x) * 0.1;
    this.y += (this.targetY - this.y) * 0.1;
  }

  updatePosition(targetX, targetY) {
    this.targetX = targetX;
    this.targetY = targetY;
  }

  updateRotation(angle) {
    this.angle = angle;
  }

  performAttack() {
    if (this.canAttack) {
      calculateAttack(this);
      this.canAttack = false;
    }
  }
}

const players = [];
const gameObjects = [];
const rooms = new Map(); // Use a Map to store rooms with room IDs

setInterval(updateGame, 1000 / tickRate);
setInterval(() => {
  log("Server has run " + ticksPassed + " ticks in the past hour");
  ticksPassed = 0;
}, 1000 * 60 * 60);

io.on('connection', (socket) => {

  const ip = socket.handshake.address;
  log("Connection from " + ip);

  const newPlayer = new Player(socket.id);
  socket.join("Lobby");
  newPlayer.roomId = "Lobby";
  players.push(newPlayer);
  log(ip + " through " + socket.id + " joined " + newPlayer.roomId);

  socket.emit('tick-rate', tickRate);

  socket.emit('heartbeat', getPlayersInRoom(newPlayer.roomId));

  socket.on('disconnect', () => {
    const disconnectedPlayer = getPlayer(socket.id);
    log(socket.id + " Disconnected");
    if (disconnectedPlayer) {
      players.splice(players.indexOf(disconnectedPlayer), 1);
    }
  });

  socket.on('update', (data) => {
    const player = getPlayer(data.id);
    if (player) {
      switch (data.type) {
        case 'position':
          player.updatePosition(data.targetX, data.targetY);
          break;
        case 'rotation':
          player.updateRotation(data.angle);
          break;
        case 'attack':
          player.performAttack();
          break;
      }
    }
  });

  socket.on('username', (username) => {
    const player = getPlayer(socket.id);
    if (player) {
      player.username = username;
    }
  });

  socket.on("ping", (callback) => {
    callback();
  });

  socket.on('client-forced-restart', () => {
    log("server restarting " + Date.now());
    process.exit();
  });

  socket.on('player-error', () => {
    const player = getPlayer(socket.id);
    log(socket.id + " had an error retreiving players");

    players.splice(players.indexOf(player), 1);
    socket.disconnect();
  });

});

function updateGame() {
  for (const player of players) {
    io.to(player.roomId).emit('heartbeat', getPlayersInRoom(player.roomId));
  }

  players.forEach((player) => player.update());

  runAttacks();
  checkLiving();
  runGameObjects();
  ticksPassed++;
}

function getPlayersInRoom(roomId) {
  return players.filter(player => player.roomId === roomId);
}

function getPlayer(id) {
  return players.find(player => player.id === id);
}

function calculateAttack(player) {
  for (const victim of players) {
    if (victim !== player) {
      const a = player.x - victim.x;
      const b = player.y - victim.y;
      const c = Math.sqrt(a * a + b * b);

      if (c < 100) {
        log(player.id + " attacked " + victim.id);
        victim.health -= serverDamage;
      }
    }
  }
}

function runAttacks() {
  for (const player of players) {
    if (player.attackTimer > 0) {
      player.attackTimer--;
    } else {
      player.canAttack = true;
      player.attackTimer = serverAttackTimer;
    }
  }
}

function checkLiving() {
  for (const player of players) {
    if (player.health <= 0) {
      log(player.id + " died");
      players.splice(players.indexOf(player), 1);
    }
  }
}

function runGameObjects() {
  gameObjects.forEach((thing) => thing.run());
}

function log(msg) {
  io.emit('log', msg);
  console.log(msg);
}

server.listen(PORT, () => {
  console.log('listening on *:' + PORT);
});
